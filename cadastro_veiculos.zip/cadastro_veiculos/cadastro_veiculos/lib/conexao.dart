import 'package:dotenv/dotenv.dart';
import 'package:supabase/supabase.dart';

/// Carrega o arquivo .env (na raiz do projeto) e cria o cliente do Supabase.
///
/// Deve ser chamada uma única vez; o mesmo cliente é reutilizado
/// enquanto o menu estiver ativo e liberado com dispose() ao encerrar.
SupabaseClient conectar() {
  final env = DotEnv(includePlatformEnvironment: true)..load();

  final url = env['SUPABASE_URL'];
  final chave = env['SUPABASE_PUBLISHABLE_KEY'];

  if (url == null || url.trim().isEmpty || chave == null || chave.trim().isEmpty) {
    throw StateError(
      'Defina SUPABASE_URL e SUPABASE_PUBLISHABLE_KEY no arquivo .env '
      'e execute o programa a partir da raiz do projeto.',
    );
  }

  return SupabaseClient(url.trim(), chave.trim());
}
