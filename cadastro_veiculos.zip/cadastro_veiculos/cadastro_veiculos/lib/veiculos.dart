import 'package:supabase/supabase.dart';

/// Nome da tabela no schema public.
const String tabelaVeiculos = 'veiculos';

/// Insere um veículo e retorna o registro criado, com o ID gerado pelo banco.
Future<Map<String, dynamic>> cadastrarVeiculo(
  SupabaseClient cliente,
  String marca,
  String modelo,
  int ano,
  double valor,
  int quilometragem,
) async {
  final registro = await cliente
      .from(tabelaVeiculos)
      .insert({
        'marca': marca,
        'modelo': modelo,
        'ano': ano,
        'valor': valor,
        'quilometragem': quilometragem,
      })
      .select()
      .single();

  return registro;
}

/// Retorna todos os veículos ordenados pelo ID (lista vazia se não houver).
Future<List<Map<String, dynamic>>> listarVeiculos(SupabaseClient cliente) async {
  final registros = await cliente
      .from(tabelaVeiculos)
      .select()
      .order('id', ascending: true);

  return registros;
}

/// Consulta um único veículo pelo ID. Retorna null se o ID não existir.
Future<Map<String, dynamic>?> buscarVeiculoPorId(
  SupabaseClient cliente,
  int id,
) async {
  final registro = await cliente
      .from(tabelaVeiculos)
      .select()
      .eq('id', id)
      .maybeSingle();

  return registro;
}

/// Atualiza todos os campos (exceto o ID) do veículo informado.
/// Retorna o registro atualizado ou null quando nenhum registro for afetado.
Future<Map<String, dynamic>?> atualizarVeiculo(
  SupabaseClient cliente,
  int id,
  String marca,
  String modelo,
  int ano,
  double valor,
  int quilometragem,
) async {
  final registros = await cliente
      .from(tabelaVeiculos)
      .update({
        'marca': marca,
        'modelo': modelo,
        'ano': ano,
        'valor': valor,
        'quilometragem': quilometragem,
      })
      .eq('id', id)
      .select();

  return registros.isEmpty ? null : registros.first;
}

/// Exclui somente o veículo com o ID informado.
/// Retorna o registro removido ou null quando nenhum registro for afetado.
Future<Map<String, dynamic>?> excluirVeiculo(
  SupabaseClient cliente,
  int id,
) async {
  final registros = await cliente
      .from(tabelaVeiculos)
      .delete()
      .eq('id', id)
      .select();

  return registros.isEmpty ? null : registros.first;
}
