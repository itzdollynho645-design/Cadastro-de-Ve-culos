-- Tabela de veículos (schema public)
-- Execute no Supabase: SQL Editor > New query > Run

create table if not exists public.veiculos (
  id            bigint generated always as identity primary key,
  marca         varchar(50)    not null check (char_length(trim(marca)) > 0),
  modelo        varchar(100)   not null check (char_length(trim(modelo)) > 0),
  ano           integer        not null check (ano >= 1900),
  valor         decimal(12, 2) not null check (valor > 0),
  quilometragem integer        not null check (quilometragem >= 0)
);

-- Acesso pela chave publishable (papel anon), já que o exercício não tem login.
-- Atenção: com estas políticas, qualquer pessoa com a chave pode ler e alterar
-- a tabela. Adequado para o exercício; não use assim em produção.
grant select, insert, update, delete on public.veiculos to anon;

alter table public.veiculos enable row level security;

drop policy if exists "veiculos_select_anon" on public.veiculos;
drop policy if exists "veiculos_insert_anon" on public.veiculos;
drop policy if exists "veiculos_update_anon" on public.veiculos;
drop policy if exists "veiculos_delete_anon" on public.veiculos;

create policy "veiculos_select_anon" on public.veiculos
  for select to anon using (true);

create policy "veiculos_insert_anon" on public.veiculos
  for insert to anon with check (true);

create policy "veiculos_update_anon" on public.veiculos
  for update to anon using (true) with check (true);

create policy "veiculos_delete_anon" on public.veiculos
  for delete to anon using (true);
