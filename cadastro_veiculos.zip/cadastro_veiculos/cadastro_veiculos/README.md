# Cadastro de Veículos — Dart + Supabase

Aplicação de terminal em Dart para uma concessionária cadastrar, listar, atualizar e excluir veículos na tabela `veiculos` do Supabase. Todas as operações funcionam em uma única execução, por meio de um menu.

## Estrutura do projeto

| Arquivo | Responsabilidade |
|---|---|
| `bin/main.dart` | Exibe o menu, lê e valida as entradas, chama os métodos e apresenta os resultados. |
| `lib/conexao.dart` | Carrega o `.env` e disponibiliza a função `conectar()`. |
| `lib/veiculos.dart` | Métodos do CRUD (`cadastrarVeiculo`, `listarVeiculos`, `atualizarVeiculo`, `excluirVeiculo`) e a consulta `buscarVeiculoPorId`. |
| `.env` | `SUPABASE_URL` e `SUPABASE_PUBLISHABLE_KEY` (não versionado). |
| `.env.example` | Modelo do `.env`, sem credenciais reais. |
| `supabase/criar_tabela_veiculos.sql` | Script de criação da tabela e das permissões. |
| `pubspec.yaml` / `.gitignore` | Dependências (`supabase`, `dotenv`) e exclusão do `.env` do versionamento. |

## Pré-requisitos

- Dart SDK 3.0 ou superior (`dart --version`)
- Um projeto no Supabase

## 1. Criar a tabela no Supabase

No painel do Supabase, abra **SQL Editor**, cole o conteúdo de `supabase/criar_tabela_veiculos.sql` e clique em **Run**.

A tabela criada é:

| Campo | Tipo |
|---|---|
| `id` | `bigint` identity, chave primária |
| `marca` | `varchar(50)` |
| `modelo` | `varchar(100)` |
| `ano` | `integer` |
| `valor` | `decimal(12,2)` |
| `quilometragem` | `integer` |

O script também libera o acesso pela chave publishable (papel `anon`), já que o exercício não usa login. Se a tabela já estiver preparada pelo professor, este passo pode ser pulado.

## 2. Configurar a conexão

Na raiz do projeto, copie o modelo e preencha com os dados do seu projeto (Supabase > **Project Settings** > **API Keys** / **Data API**):

```bash
cp .env.example .env      # Windows: copy .env.example .env
```

```env
SUPABASE_URL=https://SEU-PROJETO.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_SUA_CHAVE_AQUI
```

O `.env` está no `.gitignore` e **não deve ser enviado** ao GitHub.

## 3. Instalar as dependências e executar

Sempre na raiz do projeto (onde está o `pubspec.yaml` e o `.env`):

```bash
dart pub get
dart run bin/main.dart
```

> Se você reaproveitou o projeto da aula com outro nome no `pubspec.yaml`, ajuste os imports no início de `bin/main.dart` (`package:cadastro_veiculos/...`) para o nome do seu projeto.

## Menu

```
CADASTRO DE VEÍCULOS
1 - Cadastrar veículo
2 - Listar veículos
3 - Atualizar veículo
4 - Excluir veículo
0 - Sair
O que deseja fazer?
```

## Regras de validação

| Campo | Regra |
|---|---|
| Marca / Modelo | Espaços nas extremidades são removidos; vazio é rejeitado; máximo de 50 / 100 caracteres. |
| Ano | Inteiro entre 1900 e o ano atual + 1 (constante `anoMaximo` em `bin/main.dart`). |
| Valor | Maior que zero, até duas casas decimais, menor que 10000000000; aceita vírgula ou ponto, sem separador de milhar. |
| Quilometragem | Inteiro maior ou igual a zero (zero = veículo sem uso). |
| ID | Inteiro positivo. Não é pedido no cadastro: o ID exibido é o gerado pelo banco. |
| Exclusão | Só `S` ou `s` exclui; `N` ou `n` cancela; qualquer outra resposta é rejeitada. |

Qualquer entrada inválida mostra o motivo e volta ao menu sem gravar nada. Erros do Supabase ou de rede são tratados com `try/catch` e o menu continua disponível. O cliente do Supabase é criado uma única vez e liberado com `dispose()` no `finally` ao sair.

## Exemplo de execução (ciclo completo, sem reiniciar)

```
O que deseja fazer? 1
Marca: Chevrolet
Modelo: Onix
Ano: 2022
Valor: 65000,00
Quilometragem: 35000
Veículo cadastrado!
ID: 7 | Chevrolet Onix | Ano: 2022 | Valor: R$ 65000.00 | Quilometragem: 35000 km

O que deseja fazer? 2
----------------------------------------
ID: 7 | Marca: Chevrolet | Modelo: Onix
Ano: 2022 | Valor: R$ 65000.00
Quilometragem: 35000 km
----------------------------------------
Total: 1 veículo(s).

O que deseja fazer? 3
ID do veículo: 7
Dados atuais: ID: 7 | Chevrolet Onix | Ano: 2022 | Valor: R$ 65000.00 | Quilometragem: 35000 km
Digite todos os novos valores (repita os que deseja manter).
Nova marca: Chevrolet
Novo modelo: Onix LT
Novo ano: 2022
Novo valor: 63000.00
Nova quilometragem: 35200
Veículo atualizado!
ID: 7 | Chevrolet Onix LT | Ano: 2022 | Valor: R$ 63000.00 | Quilometragem: 35200 km

O que deseja fazer? 4
ID do veículo: 7
Veículo selecionado: ID: 7 | Chevrolet Onix LT | Ano: 2022 | Valor: R$ 63000.00 | Quilometragem: 35200 km
Confirma a exclusão? S/N: N
Exclusão cancelada.

O que deseja fazer? 4
ID do veículo: 7
Veículo selecionado: ID: 7 | Chevrolet Onix LT | Ano: 2022 | Valor: R$ 63000.00 | Quilometragem: 35200 km
Confirma a exclusão? S/N: S
Veículo excluído!
ID: 7 | Chevrolet Onix LT

O que deseja fazer? 0
Sistema encerrado.
```

O ID 7 é ilustrativo: o programa mostra o ID real retornado pelo Supabase.

## Conferência antes da entrega

| Teste | Resultado esperado |
|---|---|
| Cadastrar dois veículos | IDs distintos e dados gravados no Supabase. |
| Listar e reiniciar o programa | Registros continuam disponíveis para consulta. |
| Atualizar um veículo por ID | Somente o veículo escolhido é alterado. |
| Cancelar e confirmar uma exclusão | `N` mantém o registro; `S` remove somente o ID informado. |
| Usar ID inexistente ou tabela vazia | "Nenhum veículo encontrado com o ID X." / "Nenhum veículo cadastrado." |
| Digitar dados inválidos | Marca vazia, ano fora do limite, valor zero ou negativo e quilometragem negativa são rejeitados. |
